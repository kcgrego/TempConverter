﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TempConverter_KS
{
    public class Converter
    {
        public static double FahrentheitToCelsius(double Fahrenheit)
        {
            double celsius = (Fahrenheit - 32) * (5 / 9);
            return celsius;
        }

        public static double CelsiusToFahrentheit(double Celsius)
        {
            double fahrenheit = (Celsius + 32) * (9/5);
            return fahrenheit;

        }
    }
}
